package dungeon;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Map;

import org.bukkit.Location;
import org.bukkit.block.Block;

import com.google.common.primitives.UnsignedBytes;

import jnbt.ByteArrayTag;
import jnbt.CompoundTag;
import jnbt.NBTInputStream;
import jnbt.ShortTag;
import jnbt.StringTag;
import jnbt.Tag;

public class Schematic
{
	//��Ű��ƽ �ҽ� ��ó : https://bukkit.org/threads/pasting-loading-schematics.87129 //
 
    private byte[] blocks;
    private byte[] data;
    private short width;
    private short lenght;
    private short height;
 
    public Schematic()
    {}
    public Schematic(byte[] blocks2, byte[] blockData, short width, short lenght, short height)
    {
        this.blocks = blocks2;
        this.data = blockData;
        this.width = width;
        this.lenght = lenght;
        this.height = height;
    }
 

	//������ ��ȯ�մϴ�.//
    public byte[] getBlocks(){return blocks;}
    //���� �����͸� ��ȯ�մϴ�.//
    public byte[] getData() {return data;}
    //���� ���̸� ��ȯ�մϴ�.//
    public short getWidth(){return width;}
    //���� ���̸� ��ȯ�մϴ�.//
    public short getLenght(){return lenght;}
    //���̸� ��ȯ�մϴ�.//
    public short getHeight(){return height;}

    //������ ����ƽ ������ �ش� ��ġ�� �ٿ������ϴ�.//
	public static void pasteSchematic(Location loc, Schematic schematic)
    {
		byte[] blocks = schematic.getBlocks();
		byte[] blockData = schematic.getData();
 
        short length = schematic.getLenght();
        short width = schematic.getWidth();
        short height = schematic.getHeight();
        
        for (int x = 0; x < width; ++x) {
            for (int y = 0; y < height; ++y) {
                for (int z = 0; z < length; ++z) {
                    int index = y * width * length + z * width + x;
                    int blockid = UnsignedBytes.toInt(blocks[index]);
                    if(blockid <= -1)
                    	blockid = 1;
                    Block block = new Location(loc.getWorld(), x + loc.getX(), y + loc.getY(), z + loc.getZ()).getBlock();
                    block.setTypeIdAndData(blockid, (byte) blockData[index], true);
                }
            }
        }
    }
 
    public static Schematic loadSchematic(File file) throws IOException
    {
    	FileInputStream stream = new FileInputStream(file);
		NBTInputStream nbtStream = new NBTInputStream(stream);
        CompoundTag schematicTag = (CompoundTag) nbtStream.readTag();
        Map<String, Tag> schematic = schematicTag.getValue();
        short width = getChildTag(schematic, "Width", ShortTag.class).getValue();
        short length = getChildTag(schematic, "Length", ShortTag.class).getValue();
        short height = getChildTag(schematic, "Height", ShortTag.class).getValue();
        String materials = getChildTag(schematic, "Materials", StringTag.class).getValue();
        byte[] blocks = getChildTag(schematic, "Blocks", ByteArrayTag.class).getValue();
        byte[] blockData = getChildTag(schematic, "Data", ByteArrayTag.class).getValue();
        return new Schematic(blocks, blockData, width, length, height);
    }
 
    
    private static <T extends Tag> T getChildTag(Map<String, Tag> items, String key, Class<T> expected) throws IllegalArgumentException
    {
        if (!items.containsKey(key)) {
            throw new IllegalArgumentException("Schematic file is missing a \"" + key + "\" tag");
        }
        Tag tag = items.get(key);
        if (!expected.isInstance(tag)) {
            throw new IllegalArgumentException(key + " tag is not of tag type " + expected.getName());
        }
        return expected.cast(tag);
    }
}