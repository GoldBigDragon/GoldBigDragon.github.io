package area;

public class AreaObject
{
	public String areaName;
	public int minX;
	public int minY;
	public int minZ;
	public int maxX;
	public int maxY;
	public int maxZ;
}