package structure;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import effect.SoundEffect;
import main.MainServerOption;
import user.UserDataObject;
import util.GuiUtil;
import util.YamlLoader;

public class StructPostBox extends GuiUtil
{
	public void PostBoxMainGUI(Player player, byte Type)
	{
		YamlLoader PlayerPost = new YamlLoader();
		PlayerPost.getConfig("Post/"+player.getUniqueId().toString()+".yml");
		String UniqueCode = "��0��0��d��0��3��r";
		Inventory inv = Bukkit.createInventory(null, 45, UniqueCode + "��c��l������");
		if(Type==0)//���� ����
		{
			if(PlayerPost.contains("Recieve")==false)
			{
				PlayerPost.createSection("Recieve");
				PlayerPost.saveConfig();
			}
			Object[] PostList = PlayerPost.getConfigurationSection("Recieve").getKeys(false).toArray();
			byte loc=2;
			for(int count = 0; count < PostList.length;count++)
			{
				if(count>=25)
					break;
				String PostFrom = PlayerPost.getString("Recieve."+PostList[count].toString()+".From");
				String PostTitle = PlayerPost.getString("Recieve."+PostList[count].toString()+".Title");
				String PostMemo = PlayerPost.getString("Recieve."+PostList[count].toString()+".Memo");
				ItemStack PostItem = PlayerPost.getItemStack("Recieve."+PostList[count].toString()+".Item");

				List<String> Memo = new ArrayList<String>();
				Memo.add("");
				Memo.add("��9���� : ��f"+PostTitle);
				Memo.add("");
				for(int count2=0;count2<(PostMemo.length()/20)+1;count2++)
				{
					if((count2+1)*20<PostMemo.length())
						Memo.add("��f"+PostMemo.substring(0+(count2*20), ((count2+1)*20)));
					else
						Memo.add("��f"+PostMemo.substring(0+(count2*20), PostMemo.length()));
				}
				Memo.add("");
				Memo.add("��9���� �� : ��f"+PostFrom);
				if(PostItem==null)
				{
					Memo.add("��e[�� Ŭ���� �޽��� ����]");
					Memo.add("��0"+PostList[count].toString());
					removeFlagStack("��f[�޽���]", 358,0,1,Memo, loc, inv);
				}
				else
				{
					int PostValue = PlayerPost.getInt("Recieve."+PostList[count].toString()+".Value");
					ItemMeta PIMeta = PostItem.getItemMeta();
					if(PostItem.hasItemMeta())
					{
						Memo.add("��9��� û�� : ��f"+PostValue);
						Memo.add("��e[�� Ŭ���� ��ǰ ����]");
						if(!PlayerPost.getString("Recieve."+PostList[count]+".From").equals("[�ݼ�]")
						&&!PlayerPost.getString("Recieve."+PostList[count]+".From").equals("[��ǰ ȸ��]")
						&&!PlayerPost.getString("Recieve."+PostList[count]+".From").equals("[�ŷ� �Խ���]")
						&&!PlayerPost.getString("Recieve."+PostList[count]+".From").equals("[�̺�Ʈ]")
						&&!PlayerPost.getString("Recieve."+PostList[count]+".From").equals("[�ý���]"))
							Memo.add("��c[�� Ŭ���� ��ǰ �ݼ�]");
						Memo.add("��0"+PostList[count].toString());
					}
					else
					{
						Memo.add("��9��� û�� : ��f"+PostValue);
						Memo.add("��e[�� Ŭ���� ��ǰ ����]");
						if(!PlayerPost.getString("Recieve."+PostList[count]+".From").equals("[�ݼ�]")
						&&!PlayerPost.getString("Recieve."+PostList[count]+".From").equals("[��ǰ ȸ��]")
						&&!PlayerPost.getString("Recieve."+PostList[count]+".From").equals("[�ŷ� �Խ���]")
						&&!PlayerPost.getString("Recieve."+PostList[count]+".From").equals("[�̺�Ʈ]")
						&&!PlayerPost.getString("Recieve."+PostList[count]+".From").equals("[�ý���]"))
							Memo.add("��c[�� Ŭ���� ��ǰ �ݼ�]");
						Memo.add("��0"+PostList[count].toString());
						PIMeta.setLore(Memo);
					}
					PIMeta.setLore(Memo);
					PostItem.setItemMeta(PIMeta);
					stackItem(PostItem, loc, inv);
				}
				if(loc==6||loc==15||loc==24||loc==33||loc==42)
					loc = (byte) (loc+5);
				else
					loc++;
			}
		}
		else//���� ����
		{
			if(PlayerPost.contains("Send")==false)
			{
				PlayerPost.createSection("Send");
				PlayerPost.saveConfig();
			}
			Object[] PostList = PlayerPost.getConfigurationSection("Send").getKeys(false).toArray();
			byte loc=2;
			for(int count = 0; count < PostList.length;count++)
			{
				if(count==25)
					break;
				String PostTo = PlayerPost.getString("Send."+PostList[count].toString()+".To");
				String PostTitle = PlayerPost.getString("Send."+PostList[count].toString()+".Title");
				String PostMemo = PlayerPost.getString("Send."+PostList[count].toString()+".Memo");
				ItemStack PostItem = PlayerPost.getItemStack("Send."+PostList[count].toString()+".Item");
	
				List<String> Memo = new ArrayList<String>();
				Memo.add("");
				Memo.add("��9���� : ��f"+PostTitle);
				Memo.add("");
				for(int count2=0;count2<(PostMemo.length()/20)+1;count2++)
				{
					if((count2+1)*20<PostMemo.length())
						Memo.add("��f"+PostMemo.substring(0+(count2*20), ((count2+1)*20)));
					else
						Memo.add("��f"+PostMemo.substring(0+(count2*20), PostMemo.length()));
				}
				Memo.add("");
				Memo.add("��9�޴��� : ��f"+PostTo);
				if(PostItem==null)
				{
					Memo.add("��e[�� Ŭ���� �޽��� ���� ���]");
					Memo.add("��0"+PostList[count].toString());
					removeFlagStack("��f[�޽���]", 358,0,1,Memo, loc, inv);
				}
				else
				{
					int PostValue = PlayerPost.getInt("Send."+PostList[count].toString()+".Value");
					ItemMeta PIMeta = PostItem.getItemMeta();
					List<String> PostedItemLore = PIMeta.getLore();
					if(PostItem.hasItemMeta() && PIMeta != null)
					{
						PostedItemLore.add("��9��� û�� : ��f"+PostValue);
						PostedItemLore.add(" ");
						PostedItemLore.add("��e[�� Ŭ���� ��ǰ ȸ��]");
						PostedItemLore.add("��0"+PostList[count].toString());
						for(int count2 = 0; count2 < PostedItemLore.size(); count2++)
							Memo.add(PostedItemLore.get(count2));
					}
					else
					{
						Memo.add("��9���û�� : ��f"+PostValue);
						Memo.add(" ");
						Memo.add("��e[�� Ŭ���� ��ǰ ȸ��]");
						Memo.add("��0"+PostList[count].toString());
					}
					PIMeta.setLore(Memo);
					PostItem.setItemMeta(PIMeta);
					stackItem(PostItem, loc, inv);
				}
				if(loc==6||loc==15||loc==24||loc==33||loc==42)
					loc = (byte) (loc+5);
				else
					loc++;
			}
		}

		removeFlagStack("��c ", 66,0,1,Arrays.asList(""), 1, inv);
		removeFlagStack("��c ", 66,0,1,Arrays.asList(""), 7, inv);
		removeFlagStack("��c ", 66,0,1,Arrays.asList(""), 10, inv);
		removeFlagStack("��c ", 66,0,1,Arrays.asList(""), 16, inv);
		removeFlagStack("��c ", 66,0,1,Arrays.asList(""), 19, inv);
		removeFlagStack("��c ", 66,0,1,Arrays.asList(""), 25, inv);
		removeFlagStack("��c ", 66,0,1,Arrays.asList(""), 28, inv);
		removeFlagStack("��c ", 66,0,1,Arrays.asList(""), 34, inv);
		removeFlagStack("��c ", 66,0,1,Arrays.asList(""), 37, inv);
		removeFlagStack("��c ", 66,0,1,Arrays.asList(""), 43, inv);

		int id = 166;
		if(Type==0)//���� ����
			id = 166;
		else
			id = 54;
		removeFlagStack("��f��l[���� ����]", id,0,1,Arrays.asList("��7���� ������ Ȯ���մϴ�."), 0, inv);

		if(Type==0)//���� ����
			id = 333;
		else
			id = 166;
		removeFlagStack("��f��l[���� ����]", id,0,1,Arrays.asList("��7���� ������ Ȯ���մϴ�."), 9, inv);
		removeFlagStack("��f��l[�ݱ�]", 324,0,1,Arrays.asList("��7â�� �ݽ��ϴ�.","��0"+Type), 26, inv);
		removeFlagStack("��f��l[���� ����]", 386,0,1,Arrays.asList("��7���ο� ������ �����ϴ�."), 36, inv);
		player.openInventory(inv);
		return;
	}

	public void ItemPutterGUI(Player player)
	{
		String UniqueCode = "��1��0��d��0��4��r";
		Inventory inv = Bukkit.createInventory(null, 9, UniqueCode + "��c��l���� ������");
		removeFlagStack("��c ", 166,0,1,null, 0, inv);
		removeFlagStack("��c ", 166,0,1,null, 1, inv);
		removeFlagStack("��c ", 166,0,1,null, 2, inv);
		removeFlagStack("��c ", 166,0,1,null, 3, inv);
		removeFlagStack("��c ", 166,0,1,null, 5, inv);
		removeFlagStack("��c ", 166,0,1,null, 6, inv);
		removeFlagStack("��c ", 166,0,1,null, 7, inv);
		removeFlagStack("��c ", 166,0,1,null, 8, inv);
		player.openInventory(inv);
	}
	
	
	
	
	public void PostBoxMainGUIClick(InventoryClickEvent event)
	{
		int slot = event.getSlot();
		Player player = (Player) event.getWhoClicked();
		
		if(slot == 26)//������
		{
			SoundEffect.playSound(player, Sound.BLOCK_PISTON_CONTRACT, 0.8F, 1.8F);
			player.closeInventory();
		}
		else if(slot == 0)//������
		{
			SoundEffect.playSound(player, Sound.BLOCK_CHEST_OPEN, 0.8F, 1.0F);
			PostBoxMainGUI(player, (byte) 0);
		}
		else if(slot == 9)//�۽���
		{
			SoundEffect.playSound(player, Sound.BLOCK_CHEST_OPEN, 0.8F, 1.0F);
			PostBoxMainGUI(player, (byte) 1);
		}
		else if(slot == 36)//�� ����
		{
			YamlLoader PlayerPost = new YamlLoader();
			PlayerPost.getConfig("Post/"+player.getUniqueId().toString()+".yml");
			if(PlayerPost.contains("Send"))
				if(PlayerPost.getConfigurationSection("Send").getKeys(false).size()<25)
				{
					UserDataObject u = new UserDataObject();
					SoundEffect.playSound(player, Sound.BLOCK_CLOTH_STEP, 0.8F, 1.8F);
					u.setTemp(player, "Structure");
					u.setType(player, "Post");
					u.setString(player, (byte)0, "RN");//Reciever Nickname
					u.setString(player, (byte)1, "");//�޴���
					u.setString(player, (byte)2, "��f���� ����");//���� ����
					u.setString(player, (byte)3, "��f���� ����");//���� ����
					u.setBoolean(player, (byte)0, false);//������ �ۺ�
					u.setInt(player, (byte)0, 0);//��� û��
					player.closeInventory();
					player.sendMessage("��a[����] : ������ ���� �г����� �Է� �ϼ���.");
				}
				else
				{
					SoundEffect.playSound(player, Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.8F, 1.8F);
					player.sendMessage("��c[����] : ������ �ִ� 25�� ������ ���� �� �ֽ��ϴ�.");
				}
			else
			{
				UserDataObject u = new UserDataObject();
				SoundEffect.playSound(player, Sound.BLOCK_CLOTH_STEP, 0.8F, 1.8F);
				u.setTemp(player, "Structure");
				u.setType(player, "Post");
				u.setString(player, (byte)0, "RN");//Reciever Nickname
				u.setString(player, (byte)1, "");//�޴���
				u.setString(player, (byte)2, "��f���� ����");//���� ����
				u.setString(player, (byte)3, "��f���� ����");//���� ����
				u.setBoolean(player, (byte)0, false);//������ �ۺ�
				u.setInt(player, (byte)0, 0);//��� û��
				player.closeInventory();
				player.sendMessage("��a[����] : ������ ���� �г����� �Է� �ϼ���.");
			}
		}
		else if(slot != 1 && slot != 7 && slot != 10 && slot != 16 && slot != 19 && slot != 25 && slot != 28 && slot != 34 && slot != 37 && slot != 43)
		{
			YamlLoader PlayerPost = new YamlLoader();
			PlayerPost.getConfig("Post/"+player.getUniqueId().toString()+".yml");
			if(event.getCurrentItem().hasItemMeta())
			{
				byte Type = Byte.parseByte(ChatColor.stripColor(event.getInventory().getItem(26).getItemMeta().getLore().get(1)));
				SoundEffect.playSound(player, Sound.ENTITY_ITEM_PICKUP, 0.8F, 1.0F);
				long UTC = Long.parseLong(ChatColor.stripColor(event.getCurrentItem().getItemMeta().getLore().get(event.getCurrentItem().getItemMeta().getLore().size()-1)));
				if(Type==0)//������
				{
					if(PlayerPost.contains("Recieve."+UTC)==false)
					{
						PostBoxMainGUI(player, Type);
						return;
					}
					String Sender = PlayerPost.getString("Recieve."+UTC+".From");
					if(Sender.equals("[�ý���]")|| Sender.equals("[�ݼ�]")||
					Sender.equals("[�ŷ� ������]")||Sender.equals("[�ŷ� �Խ���]"))
					{
						if(new util.PlayerUtil().giveItem(player, PlayerPost.getItemStack("Recieve."+UTC+".Item")))
						{
							PlayerPost.removeKey("Recieve."+UTC);
							PlayerPost.saveConfig();
							PostBoxMainGUI(player, Type);
							return;
						}
						else
						{
							SoundEffect.playSound(player, Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0F, 1.8F);
							player.sendMessage("��c[����] : �κ��丮 ������ �����մϴ�!");
						}
					}
					else
					{
						Sender = Bukkit.getOfflinePlayer(Sender).getUniqueId().toString();
						YamlLoader SenderPost = new YamlLoader();
						SenderPost.getConfig("Post/"+Sender+".yml");
						if(PlayerPost.getItemStack("Recieve."+UTC+".Item")==null)
						{
							PlayerPost.removeKey("Recieve."+UTC);
							PlayerPost.saveConfig();
							SenderPost.removeKey("Send."+UTC);
							SenderPost.saveConfig();
							PostBoxMainGUI(player, Type);
							return;
						}
						else
						{
							if(event.isLeftClick())
							{
								if(PlayerPost.getInt("Recieve."+UTC+".Value")==0)
								{
									if(new util.PlayerUtil().giveItem(player, PlayerPost.getItemStack("Recieve."+UTC+".Item")))
									{
										PlayerPost.removeKey("Recieve."+UTC);
										PlayerPost.saveConfig();
										SenderPost.removeKey("Send."+UTC);
										SenderPost.saveConfig();
										PostBoxMainGUI(player, Type);
										return;
									}
									else
									{
										SoundEffect.playSound(player, Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0F, 1.8F);
										player.sendMessage("��c[����] : �κ��丮 ������ �����մϴ�!");
									}
								}
								else
								{
									if(MainServerOption.PlayerList.get(player.getUniqueId().toString()).getStat_Money()>=PlayerPost.getInt("Recieve."+UTC+".Value"))
									{
										if(new util.PlayerUtil().giveItem(player, PlayerPost.getItemStack("Recieve."+UTC+".Item")))
										{
											MainServerOption.PlayerList.get(player.getUniqueId().toString()).setStat_Money(MainServerOption.PlayerList.get(player.getUniqueId().toString()).getStat_Money()-PlayerPost.getInt("Recieve."+UTC+".Value"));
											if(MainServerOption.PlayerList.containsKey(Sender))
												MainServerOption.PlayerList.get(player.getUniqueId().toString()).setStat_Money(MainServerOption.PlayerList.get(Sender).getStat_Money()+PlayerPost.getInt("Recieve."+UTC+".Value"));
											else
											{
												YamlLoader target = new YamlLoader();
												target.getConfig("Stats/"+Sender+".yml");
												target.set("Stat.Money", target.getLong("Stat.Money")+PlayerPost.getInt("Recieve."+UTC+".Value"));
											}
											Sender = Bukkit.getPlayer(PlayerPost.getString("Recieve."+UTC+".From")).getUniqueId().toString();
											int value = PlayerPost.getInt("Recieve."+UTC+".Value");
											PlayerPost.removeKey("Recieve."+UTC);
											PlayerPost.saveConfig();
											SenderPost.removeKey("Send."+UTC);
											SenderPost.saveConfig();
											PostBoxMainGUI(player, Type);
											SendPost_Server(Sender, "[�ŷ� ������]", "[���� �Ա� �Ϸ�]", player.getName()+" �Բ��� ��� "+value+" "+main.MainServerOption.money+"��f �Ա��Ͽ����ϴ�.", null);
											return;
										}
										else
										{
											SoundEffect.playSound(player, Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0F, 1.8F);
											player.sendMessage("��c[����] : �κ��丮 ������ �����մϴ�!");
										}
									}
									else
									{
										SoundEffect.playSound(player, Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0F, 1.8F);
										player.sendMessage("��c[����] : �������� �����մϴ�!");
									}
								}
							}
							else if(event.isRightClick()&&event.getCurrentItem().getItemMeta().getLore().get(event.getCurrentItem().getItemMeta().getLore().size()-2).contains("�ݼ�")==true)
							{
								if(!PlayerPost.getString("Recieve."+UTC+".From").equals("[�ݼ�]"))
								{
									SenderPost.removeKey("Send."+UTC);
									SenderPost.saveConfig();
									Sender = Bukkit.getPlayer(PlayerPost.getString("Recieve."+UTC+".From")).getUniqueId().toString();
									SendPost_Server(Sender, "[�ݼ�]", "[��ǰ �ݼ�]", player.getName()+" �Բ��� ��ǰ�� �ݼ��Ͽ����ϴ�.", PlayerPost.getItemStack("Recieve."+UTC+".Item"));
									PlayerPost.removeKey("Recieve."+UTC);
									PlayerPost.saveConfig();
									PostBoxMainGUI(player, Type);
								}
								return;
							}
						}
					}
				}
				else//�۽���
				{
					if(PlayerPost.contains("Send."+UTC)==false)
					{
						PostBoxMainGUI(player, Type);
						return;
					}
					String Receiver = PlayerPost.getString("Send."+UTC+".To");
					Receiver = Bukkit.getOfflinePlayer(Receiver).getUniqueId().toString();
					YamlLoader ReceiverPost = new YamlLoader();
					ReceiverPost.getConfig("Post/"+Receiver+".yml");
					if(PlayerPost.getItemStack("Send."+UTC+".Item")==null)
					{
						ReceiverPost.removeKey("Recieve."+UTC);
						ReceiverPost.saveConfig();
						PlayerPost.removeKey("Send."+UTC);
						PlayerPost.saveConfig();
						PostBoxMainGUI(player, Type);
						return;
					}
					else
					{
						if(new util.PlayerUtil().giveItem(player, PlayerPost.getItemStack("Send."+UTC+".Item")))
						{
							ReceiverPost.removeKey("Recieve."+UTC+".Item");
							ReceiverPost.removeKey("Recieve."+UTC);
							ReceiverPost.saveConfig();
							PlayerPost.removeKey("Send."+UTC);
							PlayerPost.saveConfig();
							PostBoxMainGUI(player, Type);
							return;
						}
						else
						{
							SoundEffect.playSound(player, Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0F, 1.8F);
							player.sendMessage("��c[����] : �κ��丮 ������ �����մϴ�!");
						}
					}
				}
			}
		}
	}
	
	public void ItemPutterGUIClick(InventoryClickEvent event)
	{
		Player player = (Player) event.getWhoClicked();
		int slot = event.getSlot();
		

		if(slot != 4 && event.getCurrentItem().getTypeId()==166)
		{
			if(!event.getClickedInventory().getTitle().equals("container.inventory"))
			{
				SoundEffect.playSound(player, Sound.ENTITY_ITEM_PICKUP, 0.8F, 1.9F);
				event.setCancelled(true);
			}
		}
	}
	

	public void ItemPutterGUIClose(InventoryCloseEvent event)
	{
		ItemStack item = event.getInventory().getItem(4);
		Player player = (Player) event.getPlayer();
		if(item!=null)
		{
			
			UserDataObject u = new UserDataObject();
			u.setItemStack(player, item);
			SoundEffect.playSound(player, Sound.BLOCK_PISTON_CONTRACT, 1.0F, 1.0F);
			u.setString(player, (byte)0, "Value");
			u.setTemp(player,"Structure");
			player.sendMessage("��a[����] : ������ ������ ���� ����� �Է� �ϼ���.");
		}
		else
			SendPost(player);
	}


	public void SendPost(Player player)
	{
		
		UserDataObject u = new UserDataObject();
		String targetUID = Bukkit.getPlayer(u.getString(player, (byte)1)).getUniqueId().toString();
		YamlLoader TargetPost = new YamlLoader();
		TargetPost.getConfig("Post/"+targetUID+".yml");
		YamlLoader PlayerPost = new YamlLoader();
		PlayerPost.getConfig("Post/"+player.getUniqueId().toString()+".yml");
		if(TargetPost.contains("Recieve")==false)
		{
			TargetPost.createSection("Recieve");
			TargetPost.saveConfig();
		}
		if(TargetPost.contains("Send")==false)
		{
			TargetPost.createSection("Send");
			TargetPost.saveConfig();
		}
		long UTC = new servertick.ServerTickMain().nowUTC +new util.NumericUtil().RandomNum(0, 1200);
		if(TargetPost.getConfigurationSection("Recieve").getKeys(false).size()<25)
		{
			TargetPost.set("Recieve."+UTC+".From", player.getName());
			TargetPost.set("Recieve."+UTC+".Title", u.getString(player, (byte)2));
			TargetPost.set("Recieve."+UTC+".Memo", u.getString(player, (byte)3));
			TargetPost.set("Recieve."+UTC+".Item", u.getItemStack(player));
			TargetPost.set("Recieve."+UTC+".Value", u.getInt(player,(byte)0));
			PlayerPost.set("Send."+UTC+".To", u.getString(player, (byte)1));
			PlayerPost.set("Send."+UTC+".Title", u.getString(player, (byte)2));
			PlayerPost.set("Send."+UTC+".Memo", u.getString(player, (byte)3));
			PlayerPost.set("Send."+UTC+".Item", u.getItemStack(player));
			PlayerPost.set("Send."+UTC+".Value", u.getInt(player, (byte)0));
			TargetPost.saveConfig();
			PlayerPost.saveConfig();
			SoundEffect.playSound(player, Sound.BLOCK_CHEST_CLOSE, 1.0F, 1.8F);
			player.sendMessage("��a[����] : �������� �߼��Ͽ����ϴ�!");
		}
		else
		{
			SoundEffect.playSound(player, Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0F, 1.8F);
			player.sendMessage("��c[����] : �ش� �÷��̾��� �������� ���� á���ϴ�.");
			if(u.getItemStack(player)!=null)
			{
				PlayerPost.set("Recieve."+UTC+".From", "[�ý���]");
				PlayerPost.set("Recieve."+UTC+".Title", "[��� ����]");
				PlayerPost.set("Recieve."+UTC+".Memo", "[������ �������� �� á���ϴ�.]");
				PlayerPost.set("Recieve."+UTC+".Item", u.getItemStack(player));
				PlayerPost.saveConfig();
			}
		}
		u.clearAll(player);
		return;
	}

	public void SendPost_Server(String targetUUID, String Name, String Title, String Memo, ItemStack item)
	{
		YamlLoader TargetPost = new YamlLoader();
		TargetPost.getConfig("Post/"+targetUUID+".yml");
		if(TargetPost.contains("Recieve")==false)
		{
			TargetPost.createSection("Recieve");
			TargetPost.saveConfig();
		}
		long UTC = new servertick.ServerTickMain().nowUTC +new util.NumericUtil().RandomNum(0, 1200);
		TargetPost.set("Recieve."+UTC+".From", Name);
		TargetPost.set("Recieve."+UTC+".Title", Title);
		TargetPost.set("Recieve."+UTC+".Memo", Memo);
		TargetPost.set("Recieve."+UTC+".Item", item);
		TargetPost.set("Recieve."+UTC+".Value", 0);
		TargetPost.saveConfig();
		return;
	}


	public String CreatePostBox(int LineNumber, String StructureCode, byte Direction)
	{
		if(LineNumber<=19) //��ü�� �ٸ� 4��
		{
			if(LineNumber<=4)
				return "/summon minecraft:armor_stand ~-0.18 ~"+(0.652+(LineNumber*0.34))+" ~-0.28 {CustomName:\""+StructureCode+"\",ShowArms:1,Invisible:1,NoBasePlate:1,NoGravity:1,HandItems:[{id:stained_hardened_clay,Damage:14,Count:1},{}],Pose:{Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[346f,44f,270f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f],Head:[0f,0f,0f]}}";
			else if(LineNumber<=9)
				return "/summon minecraft:armor_stand ~-0.18 ~"+(0.652+((LineNumber-5)*0.34))+" ~-0.96 {CustomName:\""+StructureCode+"\",ShowArms:1,Invisible:1,NoBasePlate:1,NoGravity:1,HandItems:[{id:stained_hardened_clay,Damage:14,Count:1},{}],Pose:{Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[346f,44f,270f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f],Head:[0f,0f,0f]}}";
			else if(LineNumber<=14)
				return "/summon minecraft:armor_stand ~-0.86 ~"+(0.652+((LineNumber-10)*0.34))+" ~-0.96 {CustomName:\""+StructureCode+"\",ShowArms:1,Invisible:1,NoBasePlate:1,NoGravity:1,HandItems:[{id:stained_hardened_clay,Damage:14,Count:1},{}],Pose:{Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[346f,44f,270f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f],Head:[0f,0f,0f]}}";
			else if(LineNumber<=19)
				return "/summon minecraft:armor_stand ~-0.86 ~"+(0.652+((LineNumber-15)*0.34))+" ~-0.28 {CustomName:\""+StructureCode+"\",ShowArms:1,Invisible:1,NoBasePlate:1,NoGravity:1,HandItems:[{id:stained_hardened_clay,Damage:14,Count:1},{}],Pose:{Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[346f,44f,270f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f],Head:[0f,0f,0f]}}";
		}

		switch(Direction)
		{
		case 1://��
			switch(LineNumber)
			{
				case 25:
					return "/summon minecraft:armor_stand ~-0.86 ~1.672 ~-0.62 {CustomName:\""+StructureCode+"\",ShowArms:1,Invisible:1,NoBasePlate:1,NoGravity:1,HandItems:[{id:stained_hardened_clay,Damage:14,Count:1},{}],Pose:{Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[346f,44f,270f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f],Head:[0f,0f,0f]}}";
				case 26:
					return "/summon minecraft:armor_stand ~-0.52 ~1.672 ~-0.28 {CustomName:\""+StructureCode+"\",ShowArms:1,Invisible:1,NoBasePlate:1,NoGravity:1,HandItems:[{id:stained_hardened_clay,Damage:14,Count:1},{}],Pose:{Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[346f,44f,270f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f],Head:[0f,0f,0f]}}";
				case 27:
					return "/summon minecraft:armor_stand ~-0.52 ~1.672 ~-0.96 {CustomName:\""+StructureCode+"\",ShowArms:1,Invisible:1,NoBasePlate:1,NoGravity:1,HandItems:[{id:stained_hardened_clay,Damage:14,Count:1},{}],Pose:{Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[346f,44f,270f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f],Head:[0f,0f,0f]}}";
			}
			break;
		case 3://��
			switch(LineNumber)
			{
				case 25:
					return "/summon minecraft:armor_stand ~-0.52 ~1.672 ~-0.96 {CustomName:\""+StructureCode+"\",ShowArms:1,Invisible:1,NoBasePlate:1,NoGravity:1,HandItems:[{id:stained_hardened_clay,Damage:14,Count:1},{}],Pose:{Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[346f,44f,270f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f],Head:[0f,0f,0f]}}";
				case 26:
					return "/summon minecraft:armor_stand ~-0.52 ~1.672 ~-0.28 {CustomName:\""+StructureCode+"\",ShowArms:1,Invisible:1,NoBasePlate:1,NoGravity:1,HandItems:[{id:stained_hardened_clay,Damage:14,Count:1},{}],Pose:{Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[346f,44f,270f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f],Head:[0f,0f,0f]}}";
				case 27:
					return "/summon minecraft:armor_stand ~-0.18 ~1.672 ~-0.62 {CustomName:\""+StructureCode+"\",ShowArms:1,Invisible:1,NoBasePlate:1,NoGravity:1,HandItems:[{id:stained_hardened_clay,Damage:14,Count:1},{}],Pose:{Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[346f,44f,270f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f],Head:[0f,0f,0f]}}";
			}
			break;
		case 5://��
			switch(LineNumber)
			{
				case 25:
					return "/summon minecraft:armor_stand ~-0.86 ~1.672 ~-0.62 {CustomName:\""+StructureCode+"\",ShowArms:1,Invisible:1,NoBasePlate:1,NoGravity:1,HandItems:[{id:stained_hardened_clay,Damage:14,Count:1},{}],Pose:{Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[346f,44f,270f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f],Head:[0f,0f,0f]}}";
				case 26:
					return "/summon minecraft:armor_stand ~-0.52 ~1.672 ~-0.96 {CustomName:\""+StructureCode+"\",ShowArms:1,Invisible:1,NoBasePlate:1,NoGravity:1,HandItems:[{id:stained_hardened_clay,Damage:14,Count:1},{}],Pose:{Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[346f,44f,270f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f],Head:[0f,0f,0f]}}";
				case 27:
					return "/summon minecraft:armor_stand ~-0.18 ~1.672 ~-0.62 {CustomName:\""+StructureCode+"\",ShowArms:1,Invisible:1,NoBasePlate:1,NoGravity:1,HandItems:[{id:stained_hardened_clay,Damage:14,Count:1},{}],Pose:{Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[346f,44f,270f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f],Head:[0f,0f,0f]}}";
			}
			break;
		case 7://��
			switch(LineNumber)
			{
				case 25:
					return "/summon minecraft:armor_stand ~-0.86 ~1.672 ~-0.62 {CustomName:\""+StructureCode+"\",ShowArms:1,Invisible:1,NoBasePlate:1,NoGravity:1,HandItems:[{id:stained_hardened_clay,Damage:14,Count:1},{}],Pose:{Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[346f,44f,270f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f],Head:[0f,0f,0f]}}";
				case 26:
					return "/summon minecraft:armor_stand ~-0.52 ~1.672 ~-0.28 {CustomName:\""+StructureCode+"\",ShowArms:1,Invisible:1,NoBasePlate:1,NoGravity:1,HandItems:[{id:stained_hardened_clay,Damage:14,Count:1},{}],Pose:{Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[346f,44f,270f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f],Head:[0f,0f,0f]}}";
				case 27:
					return "/summon minecraft:armor_stand ~-0.18 ~1.672 ~-0.62 {CustomName:\""+StructureCode+"\",ShowArms:1,Invisible:1,NoBasePlate:1,NoGravity:1,HandItems:[{id:stained_hardened_clay,Damage:14,Count:1},{}],Pose:{Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[346f,44f,270f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f],Head:[0f,0f,0f]}}";
			}
			break;
		}
		
		switch(LineNumber)
		{
		case 20:
			return "/summon minecraft:armor_stand ~-0.18 ~2.012 ~-0.62 {CustomName:\""+StructureCode+"\",ShowArms:1,Invisible:1,NoBasePlate:1,NoGravity:1,HandItems:[{id:stained_hardened_clay,Damage:14,Count:1},{}],Pose:{Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[346f,44f,270f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f],Head:[0f,0f,0f]}}";
		case 21:
			return "/summon minecraft:armor_stand ~-0.52 ~2.012 ~-0.62 {CustomName:\""+StructureCode+"\",ShowArms:1,Invisible:1,NoBasePlate:1,NoGravity:1,HandItems:[{id:stained_hardened_clay,Damage:14,Count:1},{}],Pose:{Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[346f,44f,270f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f],Head:[0f,0f,0f]}}";
		case 22:
			return "/summon minecraft:armor_stand ~-0.86 ~2.012 ~-0.62 {CustomName:\""+StructureCode+"\",ShowArms:1,Invisible:1,NoBasePlate:1,NoGravity:1,HandItems:[{id:stained_hardened_clay,Damage:14,Count:1},{}],Pose:{Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[346f,44f,270f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f],Head:[0f,0f,0f]}}";
		case 23:
			return "/summon minecraft:armor_stand ~-0.52 ~2.012 ~-0.96 {CustomName:\""+StructureCode+"\",ShowArms:1,Invisible:1,NoBasePlate:1,NoGravity:1,HandItems:[{id:stained_hardened_clay,Damage:14,Count:1},{}],Pose:{Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[346f,44f,270f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f],Head:[0f,0f,0f]}}";
		case 24:
			return "/summon minecraft:armor_stand ~-0.52 ~2.012 ~-0.28 {CustomName:\""+StructureCode+"\",ShowArms:1,Invisible:1,NoBasePlate:1,NoGravity:1,HandItems:[{id:stained_hardened_clay,Damage:14,Count:1},{}],Pose:{Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[346f,44f,270f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f],Head:[0f,0f,0f]}}";

		case 28:
			return "/summon minecraft:armor_stand ~-0.18 ~1.332 ~-0.62 {CustomName:\""+StructureCode+"\",ShowArms:1,Invisible:1,NoBasePlate:1,NoGravity:1,HandItems:[{id:stained_hardened_clay,Damage:14,Count:1},{}],Pose:{Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[346f,44f,270f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f],Head:[0f,0f,0f]}}";
		case 29:
			return "/summon minecraft:armor_stand ~-0.86 ~1.332 ~-0.62 {CustomName:\""+StructureCode+"\",ShowArms:1,Invisible:1,NoBasePlate:1,NoGravity:1,HandItems:[{id:stained_hardened_clay,Damage:14,Count:1},{}],Pose:{Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[346f,44f,270f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f],Head:[0f,0f,0f]}}";
		case 30:
			return "/summon minecraft:armor_stand ~-0.52 ~1.332 ~-0.96 {CustomName:\""+StructureCode+"\",ShowArms:1,Invisible:1,NoBasePlate:1,NoGravity:1,HandItems:[{id:stained_hardened_clay,Damage:14,Count:1},{}],Pose:{Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[346f,44f,270f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f],Head:[0f,0f,0f]}}";
		case 31:
			return "/summon minecraft:armor_stand ~-0.52 ~1.332 ~-0.28 {CustomName:\""+StructureCode+"\",ShowArms:1,Invisible:1,NoBasePlate:1,NoGravity:1,HandItems:[{id:stained_hardened_clay,Damage:14,Count:1},{}],Pose:{Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[346f,44f,270f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f],Head:[0f,0f,0f]}}";

		case 32:
			return "/summon minecraft:armor_stand ~-0.18 ~0.992 ~-0.62 {CustomName:\""+StructureCode+"\",ShowArms:1,Invisible:1,NoBasePlate:1,NoGravity:1,HandItems:[{id:stained_hardened_clay,Damage:14,Count:1},{}],Pose:{Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[346f,44f,270f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f],Head:[0f,0f,0f]}}";
		case 33:
			return "/summon minecraft:armor_stand ~-0.52 ~0.992 ~-0.62 {CustomName:\""+StructureCode+"\",ShowArms:1,Invisible:1,NoBasePlate:1,NoGravity:1,HandItems:[{id:stained_hardened_clay,Damage:14,Count:1},{}],Pose:{Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[346f,44f,270f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f],Head:[0f,0f,0f]}}";
		case 34:
			return "/summon minecraft:armor_stand ~-0.86 ~0.992 ~-0.62 {CustomName:\""+StructureCode+"\",ShowArms:1,Invisible:1,NoBasePlate:1,NoGravity:1,HandItems:[{id:stained_hardened_clay,Damage:14,Count:1},{}],Pose:{Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[346f,44f,270f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f],Head:[0f,0f,0f]}}";
		case 35:
			return "/summon minecraft:armor_stand ~-0.52 ~0.992 ~-0.96 {CustomName:\""+StructureCode+"\",ShowArms:1,Invisible:1,NoBasePlate:1,NoGravity:1,HandItems:[{id:stained_hardened_clay,Damage:14,Count:1},{}],Pose:{Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[346f,44f,270f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f],Head:[0f,0f,0f]}}";
		case 36:
			return "/summon minecraft:armor_stand ~-0.52 ~0.992 ~-0.28 {CustomName:\""+StructureCode+"\",ShowArms:1,Invisible:1,NoBasePlate:1,NoGravity:1,HandItems:[{id:stained_hardened_clay,Damage:14,Count:1},{}],Pose:{Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[346f,44f,270f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f],Head:[0f,0f,0f]}}";
			
		case 37:
			return "/summon minecraft:armor_stand ~-0.28 ~1.332 ~-0.28 {CustomName:\""+StructureCode+"\",CustomNameVisible:1,ShowArms:1,Invisible:1,NoBasePlate:1,NoGravity:1}";

		}
		return "null";
	}
}
