package com.xxmicloxx.noteblockapi;

public enum FadeType {
    FADE_LINEAR
}